<?php

header("Location: logar.php");