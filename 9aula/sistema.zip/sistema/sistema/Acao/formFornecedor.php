<?php

    require __DIR__ . "../../../vendor/autoload.php";
  
  
    $fornecedor = new Fornecedor();
    $estado = new Estado();
    $pais = new Pais();
    $cidade = new Cidade();
    $conexao = new Conexao();

    
    if(isset($_POST['enviar']))
    {
       if($fornecedor->inserirFornecedor($_POST) == "ok")
       {
        echo "Inserido com sucesso";
        header("Location: ../View/fornecedor.php");
       }
       else
       {
        echo "Não deu";
       }
        
    }

?>

<!DOCTYPE html>
<html lang="pt-br">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

    <title>Aula 9</title>
  </head>
  <body>
    
  <div class="container">

  <?php require_once "../Includes/menu.php"?>

  <div class="row">

    <div class="col-md-4">
       <h1 style="text-align: center; margin-top: 40px;">Cadastro Fornecedor</h1>
    </div>

  </div>

        <form method="post" action="">
            <div class="form-group">
                <label for="exampleFormControlInput1">Nome</label>
                <input type="text" name="nome" class="form-control" placeholder="nome">
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">País</label>
                <select name="pais" class="form-control">
                    <?php 
                    foreach($pais->selecionarPais() as $resultado1)
                    { ?>

                    <option value="<?php echo $resultado1['id']; ?>"> 
                    <?php echo $resultado1['pais']; ?> 
                    </option>

                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Estado</label>
                <select name="estado" class="form-control">
                    <?php 
                    foreach($fornecedor->selecionarEstado() as $resultado2 )
                    { ?>

                    <option value="<?php echo $resultado2['id']; ?>"> 
                    <?php echo $resultado2['estado']; ?> 
                    </option>

                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlSelect1">Cidade</label>
                <select name="cidade" class="form-control">
                    <?php 
                    foreach($cidade->selecionarCidade() as $resultado3)
                    { ?>

                    <option value="<?php echo $resultado3['id']; ?>"> 
                    <?php echo $resultado3['cidade']; ?> 
                    </option>

                    <?php } ?>
                </select>
            </div>

            <div class="form-group">
                <label for="exampleFormControlInput1">Telefone</label>
                <input type="text" name="telefone" class="form-control" placeholder="telefone">
            </div>

            <div class="form-group">
                <label for="exampleFormControlTextarea1">Mensagem</label>
                <textarea class="form-control" name="mensagem" rows="3" placeholder="Mensagem"></textarea>
            </div>

        <input type="submit" name="enviar" value="Enviar" class="btn btn-primary">
    </form>

    <?php require_once "../Includes/rodape.php"?>
      
  </div>





    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
  </body>
</html>