<ul class="nav justify-content-center">
  <li class="nav-item">
    <a class="nav-link active" href="#">Home</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="cliente.php">Cliente</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#.php">Fornecedor</a>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="#.php">Produto</a>
  </li>
  <Li class="nav-item">
    <a class="nav-link" href="#.php">Usuario</a>
  </Li>
  <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
          Cadastro
        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="../View/pais.php">País</a>
          <a class="dropdown-item" href="../View/estado.php">Estado</a>
          <a class="dropdown-item" href="../View/cidade.php">Cidade</a>
        </div>
      </li>
  <li class="nav-item">
    <a class="nav-link" href="sair.php">Sair</a>
  </li>
</ul>