<?php

    require "../../vendor/autoload.php";

    class Cliente
    {
        private $nome;
        private $estado;
        private $mensagem;

        /**
         * nome
         */
        public function getNome()
        {
                return $this->nome;
        }

        public function setNome($nome): self
        {
                $this->nome = $nome;

                return $this;
        }

        /**
         * estado
         */
        public function getEstado()
        {
                return $this->estado;
        }

        public function setEstado($estado): self
        {
                $this->estado = $estado;

                return $this;
        }

        /**
         * mensagem
         */
        public function getMensagem()
        {
                return $this->mensagem;
        }

        public function setMensagem($mensagem): self
        {
                $this->mensagem = $mensagem;

                return $this;
        }

        //Chamar conexão com banco de dados
        public function __construct()
        {
            $this->con = new Conexao();
        }


        //Método para inserir cliente
        public function inserirCliente($dados)
        {
            try
            {
                $this->nome = $dados['nome'];
                $this->estado = $dados['estado'];
                $this->mensagem = $dados['mensagem'];

                $cst = $this->con->conectar()->prepare("INSERT INTO clientes (nome, estado, mensagem) VALUES (:nome, :estado, :mensagem)");
                $cst->bindParam(":nome", $this->nome, PDO::PARAM_STR);
                $cst->bindParam(":estado", $this->estado, PDO::PARAM_INT);
                $cst->bindParam(":mensagem", $this->mensagem, PDO::PARAM_STR);

                if($cst->execute())
                {
                    return "ok";
                }
                else
                {
                    echo "Não deu";
                }
            }
            catch(PDOException $ex)
            {
                echo $ex;
            }
        }

        //Método para listar clientes
        public function selecionarCliente()
        {
            try
            {
                $cst = $this->con->conectar()->prepare("SELECT i.id, i.nome, i.mensagem, t.estado
                FROM clientes i
                JOIN estado t on t.id = i.estado"); 
                $cst->execute();

                return $cst->fetchAll();
            }

            catch(PDOException $ex)
            {
                echo $ex;
            }
        }

        public function selecionarEstado()
        {
            try
            {
                $cst = $this->con->conectar()->prepare("SELECT * FROM estado"); 
                $cst->execute();

                return $cst->fetchAll();
            }

            catch(PDOException $ex)
            {
                echo $ex;
            }
        }

    }
        

?>